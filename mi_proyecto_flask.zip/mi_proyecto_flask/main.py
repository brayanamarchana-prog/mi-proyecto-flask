from flask import Flask, render_template, request

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

# ----------------- EJERCICIO 1 -----------------
@app.route("/ejercicio1", methods=["GET", "POST"])
def ejercicio1():
    if request.method == "POST":
        n1 = int(request.form["nota1"])
        n2 = int(request.form["nota2"])
        n3 = int(request.form["nota3"])
        asistencia = int(request.form["asistencia"])
        promedio = (n1 + n2 + n3) / 3
        if promedio >= 40 and asistencia >= 75:
            estado = "Aprobado"
        else:
            estado = "Reprobado"
        return render_template(
            "ejercicio1_resultado.html", promedio=round(promedio,1), estado=estado
        )
    return render_template("ejercicio1.html")

# ----------------- EJERCICIO 2 -----------------
@app.route("/ejercicio2", methods=["GET", "POST"])
def ejercicio2():
    if request.method == "POST":
        n1 = request.form["nombre1"]
        n2 = request.form["nombre2"]
        n3 = request.form["nombre3"]
        nombres = [n1, n2, n3]
        nombre_mayor = max(nombres, key=len)
        return render_template(
            "ejercicio2_resultado.html",
            nombre=nombre_mayor,
            cantidad=len(nombre_mayor),
        )
    return render_template("ejercicio2.html")

if __name__ == "__main__":
    app.run(debug=True)